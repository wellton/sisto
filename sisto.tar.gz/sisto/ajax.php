<!DOCTYPE html>
<html>
<head>
  <script src="js/funcoes.js"></script>
</head>

<body>

<p id="demo">Let AJAX change this text.</p>

<button type="button" onclick="ajax('demo', 'cadastrar.php')">Change Content</button>

</body>
</html>
