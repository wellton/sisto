<?php


  //MySQL
  mysql_connect("localhost", "root", "123");
  mysql_select_db("sisto");

  //PostgreSQL
  //pg_connect("host=localhost port=5432 dbname=sisto user=postgres password=123");
