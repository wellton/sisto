#include<stdio.h>

int main(){

  printf("teste");

  return 0;
}
