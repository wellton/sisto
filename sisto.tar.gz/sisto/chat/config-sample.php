<?
///////////////////////////////////
//         ajax im 3.41          //
//    AJAX Instant Messenger     //
//   Copyright (c) 2006-2008     //
//    http://www.ajaxim.com/     //
//   Do not remove this notice   //
///////////////////////////////////

// MySQL Database Configuration
$sql_user   = 'root';
$sql_pass   = '';
$sql_host   = 'localhost';
$sql_db     = 'ajaxim';

// This is the prefix for the ajax im MySQL tables -- this can usually be left alone.
// (If upgrading from a version < 3.1, set the prefix to '')
define('SQL_PREFIX', 'ajaxim_');

$maxBuddyIconSize = 100; // in KBs, set to 0 to disable uploads
?>
