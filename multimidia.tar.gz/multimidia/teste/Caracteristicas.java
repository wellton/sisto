/**
 *Classe com as caracteristicas da imagem
 *@author Wellton Costa de Oliveira
 */
public class Caracteristicas{
    
    double tabela_gaussf1[],tabela_gaussf2[],tabela_gaussf3[],tabela_gaussf4[],tabela_gaussf5[];//armazena os valores da funcao gaussiana
    double mediaf1,mediaf2,mediaf3,mediaf4,mediaf5;//media de cada caracteristica
    double dpf1,dpf2,dpf3,dpf4,dpf5;//desvio padrao de cada caracteristica
    private int[][] pixels;//armazana os pixels da imagem carregada
    private float[][] dts;//matriz do mapa de distancia
    private float[][] gradiente;//gradiente da imagem original
    //private float max_gradiente;//valor maximo  dentro do vetor gradiente
    private float max_dts;
    
    /**
     *Construtor
     *@param pixels - matriz de pixels da imagem original
     *@param gradiente - matriz com o gradiente da imagem original
     */
    public Caracteristicas(int[][] pixels){
        setPixels(pixels);
        initTabelaGauss();
        this.gradiente = gradiente;
    }
    
    /**
     *set do mapa de distancia
     */
    public void setDts(float[][] dts, float[][] gradiente){
        this.dts = dts;
        this.gradiente = gradiente; 
    }
    
    /**
     *set da matriz pixel
     */
    public void setPixels(int[][] pixels){
        this.pixels = pixels;
    }
    
    /**
     *instancia as tabelas gaussianas
     */
    public void initTabelaGauss(){
       tabela_gaussf1 = new double[pixels.length+1];
       tabela_gaussf2 = new double[pixels.length+1];
       tabela_gaussf3 = new double[pixels.length+1];
       tabela_gaussf4 = new double[pixels.length+1];
       tabela_gaussf5 = new double[pixels.length+1];  
    }
    
    /**
     *intensidade maxima entre dois bels
     */
    public double f1(Bel atual, Bel vizinho){
        int x1 = atual.x;
        int y1 = atual.y;
        int x2 = vizinho.x;
        int y2 = vizinho.y;
        
        if(pixels[x1][y1] >= pixels[x2][y2])
            return pixels[x1][y1];
        else
            return pixels[x2][y2];
    }
    
    /**
     *intensidade minima entre dois bels
     */
    public double f2(Bel atual, Bel vizinho){
        int x1 = atual.x;
        int y1 = atual.y;
        int x2 = vizinho.x;
        int y2 = vizinho.y;
        
        if(pixels[x1][y1] <= pixels[x2][y2])
            return pixels[x1][y1];
        else
            return pixels[x2][y2];
    }
    
    /**
     *diferenca entre a intensidade maxima e minima entre dois bels
     */
    public double f3(Bel atual, Bel vizinho){ //diferenca
        int x1 = atual.x;
        int y1 = atual.y;
        int x2 = vizinho.x;
        int y2 = vizinho.y;
        
        return Math.abs(pixels[x1][y1]-pixels[x2][y2]);
    }
    /**
     *Verificar 
     */
    public double f4(Bel atual, Bel vizinho){ 
        int x1 = atual.x;
        int y1 = atual.y;
        
        int x2 = vizinho.x;
        int y2 = vizinho.y;
        
        int t=0,v=0,u=0,w=0;
     
        if(x1<x2){
            if(y1>0)
                t = pixels[x1][y1-1];
            if(y1<255)
                v = pixels[x1][y1+1];
            if(y2>0)
                u = pixels[x2][y2-1];
            if(y2<255)
                w = pixels[x2][y2+1];
        }else if(x1>x2){
            if(y1<255)
                t = pixels[x1][y1+1];
            if(y1>0)
                v = pixels[x1][y1-1];
            if(y2<255)
                u = pixels[x2][y2+1];
            if(y2>0)
                w = pixels[x2][y2-1];
        }else if(y1<y2){
            if(x1>0)
                t = pixels[x1-1][y1];
            if(x1<255)
                v = pixels[x1+1][y1];
            if(x2>0)
                u = pixels[x2-1][y2];
            if(x2<255)
                w = pixels[x2+1][y2];
        }else if(y1>y2){
            if(x1<255)
                t = pixels[x1+1][y1];
            if(x1>0)
                v = pixels[x1-1][y1];
            if(x2<255)
                u = pixels[x2+1][y2];
            if(x2>0)
                w = pixels[x2-1][y2];
        }
        
        return (1f/3f)*(float)Math.abs(pixels[x1][y1]+ t + v - pixels[x2][y2] - u - w);
    }
    
    /**
     *trabalha com o mapa de distancia
     */
    public double f5(Bel atual, Bel vizinho){ //mapa de distancia
        int x1 = atual.x;
        int y1 = atual.y;
        int x2 = vizinho.x; 
        int y2 = vizinho.y;
        
        return  (1/(1+gradiente[x1][y1]) + (1/(1+gradiente[x2][y2])))/2.0; //+ dts[x1][y1]; //formula provisoria 
     }
    
    /**
     *trabalha com o gradiente da imagem
     */
    public double f6(Bel atual,Bel vizinho){
        int x1 = atual.x;
        int y1 = atual.y;
        int x2 = vizinho.x; 
        int y2 = vizinho.y;
        return (dts[x1][y1]);//+(dts[x2][y2]/250))/2f;
    }
    
    public double f7(Bel atual,Bel vizinho){
        return f5(atual,vizinho) + f6(atual,vizinho)*200;
    }
    /**
     *custo gaussiano para a caracteristica f1
     */
    public double gaussf1(double x){ 
        if(tabela_gaussf1[(int)x] == -1)
            tabela_gaussf1[(int)x] = Math.exp((-0.5*((x-mediaf1)/dpf1)*((x-mediaf1)/dpf1)));
        return tabela_gaussf1[(int)x];
    }
    
    /**
     *custo gaussiano para a caracteristica f2
     */
    public double gaussf2(double x){
        if(tabela_gaussf2[(int)x] == -1)
            tabela_gaussf2[(int)x] = Math.exp((-0.5*((x-mediaf2)/dpf2)*((x-mediaf2)/dpf2)));
        return tabela_gaussf2[(int)x];
    }
    
    /**
     *custo gaussiano para a caracteristica f3
     */
    public double gaussf3(double x){
        if(tabela_gaussf3[(int)x] == -1)
            tabela_gaussf3[(int)x] = Math.exp((-0.5*((x-mediaf3)/dpf3)*((x-mediaf3)/dpf3)));
        return tabela_gaussf3[(int)x];
    }
    
    /**
     *custo gaussiano para a caracteristica f4
     */
    public double gaussf4(double x){
        if(tabela_gaussf4[(int)x] == -1)
            tabela_gaussf4[(int)x] = Math.exp((-0.5*((x-mediaf4)/dpf4)*((x-mediaf4)/dpf4)));
        return tabela_gaussf4[(int)x];
    }
    
    /**
     *custo gaussiano para a caracteristica f5
     */
    public double gaussf5(double x){
        if(tabela_gaussf5[(int)x] == -1)
            tabela_gaussf5[(int)x] = Math.exp(-0.5*((x)/5)*((x)/5));
        return tabela_gaussf5[(int)x];
    }
    
    /**
     *obtem  o custo conjunto
     */
    public double custo(Bel atual, Bel vizinho) { 
        if(dts==null)
            return 1-1f/3f*(gaussf1(f1(atual, vizinho))+gaussf2(f2(atual, vizinho))+gaussf3(f3(atual, vizinho)));//sem o mapa de distancia
        else{            
            return f6(atual, vizinho)+f5(atual,vizinho);//com o mapa de distancia
        }
    }
    
    /**
     *modifica os valores das tabelas gaussianas para -1
     */
    public void resetaGauss() {
        for(int i = 0; i < pixels.length; i++){
            tabela_gaussf1[i] = -1;
            tabela_gaussf2[i] = -1;
            tabela_gaussf3[i] = -1;
            tabela_gaussf4[i] = -1;
            tabela_gaussf5[i] = -1;
        }
    }
    
    /**
     *realiza o treinamento 
     */
    public void treinar(Bel inicial) {
        System.out.println("Treinando");
        //max_gradiente = 0;
        double tempf1,tempf2,tempf3,tempf4;
        int count = 0;
        int vizinhos[][] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};//vizinhos 8-adjacentes
        double somaf1 = 0, somaf2 = 0, somaf3 = 0, somaf4 = 0;
        Bel atual = inicial;
        Bel adjacente8;
        int x_adjacente,y_adjacente;
        
        mediaf1 = mediaf2 = mediaf3 = mediaf4 = 0; // media de cada caracteristica, exceto a f5 e f6
        
        if(inicial == null){
            return;
        }
        
        if(inicial.anterior == null)
            return;
        
        while(atual != null && (count == 0 || atual != inicial)) {
            for(int i=0;i<vizinhos.length;i++){
                x_adjacente = atual.x + vizinhos[i][0];
                y_adjacente = atual.y + vizinhos[i][1];
                if(x_adjacente < pixels.length && x_adjacente >= 0 && y_adjacente < pixels.length && y_adjacente >=0) {
                    count++;
                    adjacente8 = new Bel(x_adjacente,y_adjacente);
                    
                    tempf1 = f1(atual,adjacente8);
                    tempf2 = f2(atual,adjacente8);
                    tempf3 = f3(atual,adjacente8);
                    tempf4 = f4(atual,adjacente8);
                                    
                    mediaf1 += tempf1;
                    somaf1 += tempf1 * tempf1;
                    
                    mediaf2 += tempf2;
                    somaf2 += tempf2 * tempf2;
                    
                    mediaf3 += tempf3;
                    somaf3 += tempf3 * tempf3;
                    
                    mediaf4 += tempf4;
                    somaf4 += tempf4 * tempf4;
                    
                }
            }
            
            //if(max_gradiente<gradiente[atual.x][atual.y])
             // max_gradiente = gradiente[atual.x][atual.y]; // obtem o valor maximo da caracteristica f6
            
            atual = atual.anterior;
        }
        
        mediaf1 /= (double)count;//media f1
        mediaf2 /= (double)count;//media f2
        mediaf3 /= (double)count;//media f3
        mediaf4 /= (double)count;//media f4
        
        dpf1 = Math.sqrt((somaf1 - 2 * mediaf1 * mediaf1 * (double)count + mediaf1
                * mediaf1 * (double)count)/(double)(count-1)); //desvio padrao
        
        dpf2 = Math.sqrt((somaf2 - 2 * mediaf2 * mediaf2 * (double)count + mediaf2
                * mediaf2 * (double)count)/(double)(count-1)); //desvio padrao
        
        dpf3 = Math.sqrt((somaf3 - 2 * mediaf3 * mediaf3 * (double)count + mediaf3
                * mediaf3 * (double)count)/(double)(count-1)); //desvio padrao
        
        dpf4 = Math.sqrt((somaf4 - 2 * mediaf4 * mediaf4 * (double)count + mediaf4
                * mediaf4 * (double)count)/(double)(count-1)); //desvio padrao
        
        resetaGauss();
        
    }  
}
