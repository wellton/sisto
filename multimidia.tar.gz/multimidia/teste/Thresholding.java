 /*
 * Thresholding.java
 *
 * Created on 9 de Abril de 2007, 11:42
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 *//**
 *
 * @author wellton
 */

import javax.swing.JOptionPane;
import java.io.*;
import javax.imageio.*;
import java.awt.image.*;

public class Thresholding {    
    /** Creates a new instance of Thresholding */
    public Thresholding(){}
        
        public float[][] Executar(String imagem, String nomeImagem){               
		float[][] imagemBin = null;
		try{
                    String limiarString="";
                    int limiar = 0;
                
                limiarString = JOptionPane.showInputDialog(null, "Especifique o Valor do Limiar", "Limiar...", JOptionPane.QUESTION_MESSAGE);
                limiar = Integer.parseInt(limiarString);  
                  //Le o Arquivo (no caso, a imagem em escala de cinza)
			BufferedImage image = ImageIO.read(new File(imagem));

			int linha = image.getWidth();
                        int coluna =image.getHeight();                                                                       
                       
			int nbands = image.getSampleModel().getNumBands();

			Raster inputRaster = image.getData();

			int []pixels = new int[nbands*linha*coluna];
                        
		        imagemBin = new float[linha][coluna];
                   
                        inputRaster.getPixels(0,0,linha,coluna,pixels);				
                        
                        for(int w=0; w < linha; w++){
                            for(int h=0; h < coluna; h++){				
					int offset = h * linha * nbands + w * nbands;
					for(int band=0; band<nbands; band++){                                           
					   imagemBin[w][h] = pixels[offset+band];
                                           
                                           if(imagemBin[w][h] < limiar){
                                               
                                              imagemBin[w][h]=0;
                                              
                                           }else if(imagemBin[w][h] >= limiar){
                                              imagemBin[w][h]=255;
                                           }
					}                                                                        
				}
                                
			}                 
		        JOptionPane.showMessageDialog(null, "Binarizacaoo Completa!", "Completo", JOptionPane.INFORMATION_MESSAGE);
		}catch(Exception e){
			e.printStackTrace();
		}
                
                gravaThre(imagemBin, "ImagemBinarizada", "jpg");
		return imagemBin;                        
    }         
        
        /**
	* armazena uma imagem	
	*/
	public static void gravaThre(float[][] imagemGradiente, String nomeImagem, String extensao){                
		BufferedImage image = new BufferedImage(imagemGradiente.length,imagemGradiente.length,BufferedImage.TYPE_BYTE_GRAY);
		
		WritableRaster raster = image.getRaster();
		
		for(int h=0; h < imagemGradiente.length; h++)
			for(int w=0; w < imagemGradiente[h].length; w++)
				raster.setSample(h,w,0,imagemGradiente[h][w]);
		try{
			ImageIO.write(image, extensao, new File(nomeImagem+"."+extensao));                        
		}catch(IOException e){
			e.printStackTrace();
		}
	}
}
