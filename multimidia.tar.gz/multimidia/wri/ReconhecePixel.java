import java.io.*;
/**
 *
 * @author wellton
 */
public class ReconhecePixel {
    
    /** Creates a new instance of ReconhecePixel */
    public ReconhecePixel() {
    }
    
}
