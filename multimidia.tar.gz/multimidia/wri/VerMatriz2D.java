import java.awt.*;
import javax.swing.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.event.InternalFrameAdapter;  
import javax.swing.event.InternalFrameEvent;

/** Classe para visualizar imagens 2D
    Visualiza matrix2D com dados no formato double.
    Escala na faixa 0-255, onde 0 esta associado ao minimo da matriz
    e 255 ao maximo (incluindo valores negativos)
*/
public class VerMatriz2D extends JInternalFrame {
        private ComponentesMatriz2D m2dc;
        private int width,height;
        private float matrizEnviar[][];          
    
        public VerMatriz2D(String titulo, boolean modal, int loc_x, int loc_y, final String imagem, final String nomeImagem){
            super(titulo,modal, true, true, true);
            JButton botaoThresh = new JButton("Thresholding");
            botaoThresh.setActionCommand("Thresholding");            
            JButton botaoGradiente = new JButton("Gradiente");
            botaoGradiente.setActionCommand("Gradiente");
            JButton botaoFEL = new JButton("Filtragem");
            botaoFEL.setActionCommand("Filtragem");
            
            Container container = getContentPane();
            
            m2dc = new ComponentesMatriz2D(this,titulo);
            this.getContentPane().add(m2dc);
                        
            JPanel painelBotoes = new JPanel();            
            
            //painelBotoes.add(botaoThresh);            
            painelBotoes.add(botaoGradiente);
            painelBotoes.add(botaoFEL);
            container.add(painelBotoes, BorderLayout.NORTH);                        

            botaoThresh.addActionListener(
                 new ActionListener(){
                    public void actionPerformed(ActionEvent ae){
                       if (ae.getActionCommand().equals("Thresholding")){                                                      
                           Thresholding t = new Thresholding();
                           t.Executar(imagem, nomeImagem);
                       }   
                    }
                 }
            );     
            
            botaoFEL.addActionListener(
               new ActionListener(){
                  public void actionPerformed(ActionEvent e){
                     if(e.getActionCommand().equals("Filtragem")){
                        FiltragemLowpass fl = new FiltragemLowpass();
                        fl.getExecutar(imagem, nomeImagem);
                     }
                  }
               }        
            );
            
            botaoGradiente.addActionListener(
                 new ActionListener(){
                    public void actionPerformed(ActionEvent ae){
                       if (ae.getActionCommand().equals("Gradiente")){                           
                           Gradiente g = new Gradiente();
                           g.getExecutar(imagem, nomeImagem);
                       }   
                    }
                 }
            ); 
            
            

            setDefaultCloseOperation(DISPOSE_ON_CLOSE);              
            this.setLocation(loc_x,loc_y);
        }
        
        public void dados(int nX, int nY, float f[][]){
            this.matrizEnviar = f;
            setSize(nX+8,nY+70);
            m2dc.mostrar(nX,nY, matrizEnviar);
        }
        
} // fim da classe