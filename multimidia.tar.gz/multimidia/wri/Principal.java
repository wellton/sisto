/*
 * Principal.java
 *
 * Created on 6 de Abril de 2007, 13:13
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
/**
 *
 * @author wellton
 */

//package wri;

import javax.swing.*;
import java.awt.*;
 
public class Principal
{
	public static void main (String args[])
	{
		FramePrincipal framePrincipal = new FramePrincipal();
		framePrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                Toolkit tk = Toolkit.getDefaultToolkit();        
                int largura = ((int) tk.getScreenSize().getWidth());
                int altura = ((int) tk.getScreenSize().getHeight());

		framePrincipal.setSize(950, 550);
		framePrincipal.setVisible(true);
	}
}
