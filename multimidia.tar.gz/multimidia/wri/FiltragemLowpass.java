/*
 * FiltragemLowpass.java
 *
 * Created on 19 de Abril de 2007, 08:59
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

import javax.swing.JOptionPane;
import java.io.*;
import javax.imageio.*;
import java.awt.image.*;

/**
 *
 * @author wellton
 */
public class FiltragemLowpass {
    
    private float matFEL[][];
    private Pixel p;
    private float matOrig[][];
            
    /** Creates a new instance of FiltragemLowpass */
    public FiltragemLowpass() {}
    
    public float[][] getExecutar(String imagem, String nomeImagem){                       
        p = new Pixel();       
        
        matOrig = p.getPixel( imagem );
                
	float[][] matFEL = null;
	try{
                    String inputMaskString="";
                    int inputMask = 0;
                
                    inputMaskString = JOptionPane.showInputDialog(null, "Especifique o Valor da Mascara", "Mascara...", JOptionPane.QUESTION_MESSAGE);
                    inputMask = Integer.parseInt(inputMaskString);  
                    
                    //Le o Arquivo (no caso, a imagem em escala de cinza)
		    BufferedImage image = ImageIO.read(new File(imagem));

			int largura = image.getWidth(); // X
                        int altura =image.getHeight();  // Y                        
                        
                        int divi = inputMask * inputMask;
			int nbands = image.getSampleModel().getNumBands();

			Raster inputRaster = image.getData();

			int []pixels = new int[nbands*largura*altura];
                        
		        matFEL = new float[largura][altura];
                   
                        inputRaster.getPixels(0,0,largura,altura,pixels);				
                                                
                        int soma=0;
		        int m=0;
		        int n=0;

                     for(int linhaP=0; linhaP < largura; linhaP++){
		        for(int colunaP=0; colunaP < altura; colunaP++){				

				soma=0;

			        //Comecando a percorrer a matriz com a mascara
 			        for(int linha=m; linha<m+inputMask; linha++){
				   for(int coluna=n; coluna<n+inputMask; coluna++){
					soma += matOrig[linha][coluna];                        	        
				   }     				   
	                        }  				
        	                matOrig[linhaP][colunaP] = soma/divi;			
				n++;
                         }
			 m++; n=0;
                      }
		    
                        JOptionPane.showMessageDialog(null, "Filtragem Especial Lowpass Completa!", "Completo", JOptionPane.INFORMATION_MESSAGE);
		
                }catch(Exception e){
			e.printStackTrace();
		}
                
                gravaFEL(matOrig, "ImagemFiltradaLowpass", "jpg");
		return matOrig;
    }         
        
        /**
	* armazena uma imagem	
	*/
	public static void gravaFEL(float[][] matFEL, String nomeImagem, String extensao){                
		BufferedImage image = new BufferedImage(matFEL.length,matFEL.length,BufferedImage.TYPE_BYTE_GRAY);
		
		WritableRaster raster = image.getRaster();
		
		for(int h=0; h < matFEL.length; h++)
			for(int w=0; w < matFEL[h].length; w++)
				raster.setSample(h,w,0,matFEL[h][w]);
		try{
			ImageIO.write(image, extensao, new File(nomeImagem+"."+extensao));                        
		}catch(IOException e){
			e.printStackTrace();
		}
	}                
}
