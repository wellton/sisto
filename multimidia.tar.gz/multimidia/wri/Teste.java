public class Teste{
   public Teste(){
      System.out.println("Wellton");
   }
}