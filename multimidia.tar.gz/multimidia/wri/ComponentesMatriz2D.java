import java.awt.*;
import javax.swing.*;
import java.awt.image.*;
import java.awt.event.*;

public class ComponentesMatriz2D extends JComponent{
    private int width;
    private int height;
    private float[][] matriz;
    private BufferedImage images;
    private double min, max;
    private JInternalFrame jif;
    private String titulo;

    public ComponentesMatriz2D(JInternalFrame jif,String titulo){
        this.jif = jif;
        this.titulo = titulo;  
        
        addMouseMotionListener(
            new MouseMotionAdapter() {
                public void mouseMoved(MouseEvent evt){
                    atualizar_title(evt);                    
	    	}
            }
	);
    }
    public void mostrar(int nX, int nY, float f[][]){
        double dx;
        int x;
        
        width=nX;
        height=nY;
           
        min=max=f[0][0];
        matriz=new float[nX][nY];
        for(int i=0; i<width;i++)
            for(int j=0; j<height;j++){
                if(f[i][j] < min)
                    min =f[i][j];
                if(f[i][j] > max)
                    max=f[i][j];
            
                matriz[i][j]=f[i][j];
        }
        
        images=new BufferedImage(width, height,BufferedImage.TYPE_INT_RGB);
        // convertendo num inteiro em RGB
        int[] tmp=new int[width*height];
        for(int lin=0; lin< height; lin++)
            for(int col=0; col<width; col++){
                dx=matriz[col][lin];
                x=(int)(255.0*(dx-min)/(max-min));
                x=x & 0x000000ff;
                x=x<<16 | x<<8 |x;
                tmp[lin*width+col]=x;
            }
        images.setRGB(0,0,width,height,tmp,0,width);
              
    }
     public void atualizar_title(MouseEvent evt) {
        int  xAtual, yAtual;
        xAtual=evt.getX();
        yAtual=evt.getY();
        if(xAtual >= width)
            return;
        if(yAtual >= height)
            return;
        
//        jif.setTitle(xAtual+","+yAtual+"= "+matriz[xAtual][yAtual]);
        jif.setTitle("Pixel["+xAtual+"]["+yAtual+"] = "+matriz[xAtual][yAtual]);

  }
  
    public void paintComponent(Graphics g){
        super.paintComponent(g);
        BufferedImage bimg=images;
        if(bimg !=null){
          g.drawImage(bimg,0,0,this);
        }
    }

    public void visualizar(){
     repaint();
    }
}
