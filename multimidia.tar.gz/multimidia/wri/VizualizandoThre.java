/*
 * VizualizandoThre.java
 *
 * Created on 16 de Abril de 2007, 09:51
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

import java.awt.*;
import javax.swing.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.event.InternalFrameAdapter;  
import javax.swing.event.InternalFrameEvent;

/**
 *
 * @author wellton
 */

public class VizualizandoThre extends JInternalFrame{
        private ComponentesMatriz2D m2dc;
        private int width,height;
        private float matrizEnviar[][];          
/** Classe para visualizar imagens 2D
    Visualiza matrix2D com dados no formato double.
    Escala na faixa 0-255, onde 0 esta associado ao minimo da matriz
    e 255 ao maximo (incluindo valores negativos)
*/    
    /** Creates a new instance of VizualizandoThre */
    public VizualizandoThre(String titulo, boolean modal, int loc_x, int loc_y, final String imagem, final String nomeImagem ) {
        
            super(titulo, modal, true, true, true);            
            Container container = getContentPane();
            
            m2dc = new ComponentesMatriz2D(this, titulo);
            this.getContentPane().add(m2dc);                        
            
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);              
            this.setLocation(loc_x,loc_y);           
            
        }
        
        public void dados(int nX, int nY, float f[][]){
            this.matrizEnviar = f;
            setSize(nX,nY);
            m2dc.mostrar(nX,nY,matrizEnviar);
        }
    }