//package wri;

// Java core packages
import java.awt.*;
import java.awt.event.*;

// Java extension packages
import javax.swing.*;
import java.io.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.*;
import javax.swing.JOptionPane;
import java.io.*;
import javax.imageio.*;
import java.awt.image.*;
import javax.swing.event.InternalFrameAdapter;
 
public class FramePrincipal extends JFrame
{
        private JDesktopPane theDesktop;
	private String imagem;
        private Pixel pixel;
        private VerMatriz2D verMatriz2D;
        private float matrizImagem [][];
        //private VerMatriz2D wso;
        
        public FramePrincipal()	{
		super("W-R-I");
		setLayout(new BorderLayout(5, 5));	
		
	        JMenuBar barra = new JMenuBar(); 
                JMenu menuArquivo = new JMenu( "Arquivo" ); 
                
                JMenuItem itemAbrirImagem = new JMenuItem( "Abrir Imagem" ); 
                menuArquivo.add( itemAbrirImagem ); 
                
                menuArquivo.addSeparator();
                
                JMenuItem itemSair = new JMenuItem("Sair");
                menuArquivo.add( itemSair );
                
                barra.add( menuArquivo ); 
                setJMenuBar( barra ); 
      
                theDesktop = new JDesktopPane(); 
                add( theDesktop, BorderLayout.CENTER );                
      
                itemAbrirImagem.addActionListener(new EventoAbrir());                   
                itemSair.addActionListener(new EventoSair());             	
        }	
        
        private class EventoAbrir implements ActionListener{       
            // display new internal window
            public void actionPerformed( ActionEvent event ) 
            {
                String caminhoImagem="";
                JFileChooser fc = new JFileChooser();
                fc.addChoosableFileFilter(new FiltrarImagem());
                fc.setFileView(new ImagemArquivo());
                fc.setAccessory(new PreVerImagem(fc));
                           
                int returnVal = fc.showDialog(FramePrincipal.this, "Abrir");
            
                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    File file = fc.getSelectedFile();                
                    imagem = file.getName();                
                    String diretorio = fc.getCurrentDirectory().getAbsolutePath();
                
                     caminhoImagem = diretorio + "/" + imagem;
                     System.out.println("Imagem Escolhida: " + caminhoImagem);
                } else {
                    System.out.println("Erro!!");
                }
      
                if(caminhoImagem.equals("")){
                    System.out.println("Opcao Cancelada, nenhuma imagem escolhida");
                } else {                    
                    InternalFrame(caminhoImagem, imagem);          
                } 
            }
        }    
        
        //public class InternalFrame{            
            //String imagem;
           // create internal frame
                public void InternalFrame( String caminhoImagem, String nomeImagem ){
                    System.out.println("-----------------------------------------");
                    //PARTE ADCIONADA
                    pixel=new Pixel();                                        
                    int altura = pixel.getAltura( caminhoImagem );
                    int largura = pixel.getLargura( caminhoImagem );                   
                    
                    matrizImagem = pixel.getPixel( caminhoImagem );  
                    
                    VerMatriz2D frame = new VerMatriz2D("titulo",false,100,50, caminhoImagem, nomeImagem);
                    frame.pack(); // set internal frame to size of contents                    
                    theDesktop.add( frame ); 
                    frame.setVisible(true);   
                    frame.dados(largura, altura, matrizImagem);                    
                    
                }    
                
                public void AbrirLogoDepois( String caminhoImagem, String nomeImagem ){
                    System.out.println("ohhhhhhh, rapaaaaaa!!!!");
                    System.out.println(caminhoImagem);
                     System.out.println(nomeImagem);
                    //PARTE ADCIONADA
                    pixel=new Pixel();                                        
                    int altura = pixel.getAltura( caminhoImagem );
                    int largura = pixel.getLargura( caminhoImagem );                   
                    
                    matrizImagem = pixel.getPixel( caminhoImagem );  
                    
                    VizualizandoThre frame = new VizualizandoThre("titulo",false,100,50, caminhoImagem, nomeImagem);
                    
                    frame.pack(); // set internal frame to size of contents                                        
                    theDesktop.add( frame ); 
                    frame.setVisible(true);                       
                    frame.dados(largura, altura, matrizImagem);                    
                    
                }    
        //}
        
        
        private class EventoSair implements ActionListener{
            public void actionPerformed( ActionEvent evento ){
               int n= JOptionPane.showConfirmDialog(null, "Deseja realmente sair?", "Saindo", JOptionPane.YES_NO_OPTION);
               if(n==0){
                  System.exit(0);     
               }                 
            }
        }
        
            
}
