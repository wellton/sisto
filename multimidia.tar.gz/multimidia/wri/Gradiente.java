/*
 * FiltragemLowpass.java
 *
 * Created on 19 de Abril de 2007, 08:59
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

import javax.swing.JOptionPane;
import java.io.*;
import javax.imageio.*;
import java.awt.image.*;

/**
 *
 * @author wellton
 */
public class Gradiente{
    
    //private float matFEL[][];
    private Pixel p;
    private float matOrig[][];
    private float[][] matGrad;
            
    /** Creates a new instance of FiltragemLowpass */
    public Gradiente() {}
    
    public float[][] getExecutar(String imagem, String nomeImagem){                       
        p = new Pixel();       
        
        matOrig = p.getPixel( imagem );
                
	float[][] matFEL = null;
	try{
                    String inputMaskString="";
                    int inputMask = 0;
                
                    //inputMaskString = JOptionPane.showInputDialog(null, "Especifique o Valor da Mascara", "Mascara...", JOptionPane.QUESTION_MESSAGE);
                    //inputMask = Integer.parseInt(inputMaskString);  
                    
                    //Le o Arquivo (no caso, a imagem em escala de cinza)
		    BufferedImage image = ImageIO.read(new File(imagem));

			int largura = image.getWidth(); // X
                        int altura =image.getHeight();  // Y                        
                        
                        int divi = inputMask * inputMask;
			int nbands = image.getSampleModel().getNumBands();

			Raster inputRaster = image.getData();

			int []pixels = new int[nbands*largura*altura];
                        
		        matFEL = new float[largura][altura];
                   
                        inputRaster.getPixels(0,0,largura,altura,pixels);				
                                                
                        int L1=0, L3=0, C1=0, C3=0;
		        int m=0;
		        int n=0;
                        
                        
                        int[][] vizinhos = {
                            {-1,-1},
                            {-1,0},
                            {-1,1},
                            {0,-1},
                            {0,0},
                            {0,1},
                            {1,-1},
                            {1,0},
                            {1,1}
                         };
                        
                        int i,j;
                        matGrad = new float[largura][altura];
                        for(int linhaP=1; linhaP < largura-1; linhaP++){                            
                            for(int colunaP=1; colunaP < altura-1; colunaP++){
                                float[] cord = new float[9];
                                for(int x=0;x<vizinhos.length;x++){
                                    i = linhaP + vizinhos[x][0];
                                    j = colunaP + vizinhos[x][1];
                                    
                                    cord[x] = matOrig[i][j];
                                }
                                float esquerda = Math.abs((cord[6]*-1 + cord[7]*0 +cord[8]) - (cord[0]*-1 +cord[1]*-0 +cord[2]));
                                float direita =  Math.abs((cord[2]*1 +cord[5]*2 +cord[8]*1) - (cord[0]*-1 +cord[3]*-2 +cord[6]*-1));
                                
                                matGrad[linhaP][colunaP] = esquerda + direita;
                            }
                        }

                     /*matGrad = new float[largura][altura];
                     for(int linhaP=1; linhaP < largura-1; linhaP++){                            
		        for(int colunaP=1; colunaP < altura-1; colunaP++){								
                                L1=0; L3=0; C1=0; C3=0;
			        //Comecando a percorrer a matriz com a mascara
 			        for(int linha=m; linha<m+3; linha++){
				   for(int coluna=n; coluna<n+3; coluna++){                                
					//System.out.println("matOrig["+linha+"]["+coluna+"]= "+matOrig[linha][coluna]);
                                        if(linha==m && coluna==n){
                                            L1 += matOrig[linha][coluna]*(-1);
                                            C1 += matOrig[linha][coluna]*(-1);                                               
                                        }else
                                        if(linha==m && coluna==n+1){
                                            L1 += matOrig[linha][coluna]*(-1);                                               
                                        }else                                                                                    
                                        if(linha==m && coluna==n+2){
                                            L1 += matOrig[linha][coluna]*(-1);                                              
                                        }else                                            
                                        if(linha==m+2 && coluna==n){
                                            L3 += matOrig[linha][coluna];   
                                        }else                                                                                        
                                        if(linha==m+2 && coluna==n+1){
                                            L3 += matOrig[linha][coluna];   
                                        }else                                            
                                        if(linha==m+2 && coluna==n+2){
                                            L3 += matOrig[linha][coluna];                                               
                                            C3 += matOrig[linha][coluna];   
                                        }else                                            
                                        if(linha==m+1 && coluna==n){
                                            C1 += matOrig[linha][coluna]*0;   
                                        }else                                            
                                        if(linha==m+2 && coluna==n){
                                            C1 += matOrig[linha][coluna];   
                                        }else                                                                                  
                                       if(linha==m && coluna==n+2){
                                            C3 += matOrig[linha][coluna]*(-1);   
                                        }else                                                                                  
                                       if(linha==m+1 && coluna==n+2){
                                            C3 += matOrig[linha][coluna]*0;   
                                        }                                            
				   }                                                                                                         
	                        }  				
                                //System.out.println("------------------");
        	                matGrad[linhaP][colunaP] = Math.abs( (L3-L1) + (C3-C1) );
				n++;                                
                         }                        
			 m++;
                         n=0;
                      }
                        
                       */ 
                        
                      JOptionPane.showMessageDialog(null, "Gradiente Completo!", "Completo", JOptionPane.INFORMATION_MESSAGE);		
                }catch(Exception e){
			e.printStackTrace();
		}
                
                gravaGradiente(matGrad, "ImagemGradiente", "jpg");
		return matGrad;
    }         
        
        /**
	* armazena uma imagem	
	*/
	public static void gravaGradiente(float[][] matGradiente, String nomeImagem, String extensao){                
		BufferedImage image = new BufferedImage(matGradiente.length,matGradiente.length,BufferedImage.TYPE_BYTE_GRAY);
		
		WritableRaster raster = image.getRaster();
		
		for(int h=0; h < matGradiente.length; h++)
			for(int w=0; w < matGradiente[h].length; w++)
				raster.setSample(h,w,0,matGradiente[h][w]);
		try{
			ImageIO.write(image, extensao, new File(nomeImagem+"."+extensao));                        
		}catch(IOException e){
			e.printStackTrace();
		}
	}                
}
