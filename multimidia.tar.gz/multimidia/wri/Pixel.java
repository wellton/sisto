import java.io.*;
import javax.imageio.*;
import java.awt.image.*;

/**
 * @Author: Wendeson Oliveira 
 * @Date: 30 de marco de 2007
 * Classe responsavel por manipular os pixels da imagem
 */
public class Pixel{
	
	/**
	 *instancia um novo Pixel
	 */        
	public Pixel(){}
	
	/**
	 * retorna os pixels da imagem
	 * @param str_img - caminho da imagem no arquivo
	 * @return uma matriz de inteiros do tamanho da imagem
	 */
	public float[][] getPixel(String str_img){
                //System.out.println("Wellton");
		float[][] mtzImg = null;
		try{
                  //Le o Arquivo (no caso, a imagem em escala de cinza)
			BufferedImage image = ImageIO.read(new File(str_img));

			int linha = image.getWidth();
                        //System.out.println("Largura= "+linha);
                        int coluna =image.getHeight();                       
                        //System.out.println("Altura= "+coluna);
                       
			int nbands = image.getSampleModel().getNumBands();

			Raster inputRaster = image.getData();

			int []pixels = new int[nbands*linha*coluna];
			mtzImg = new float[linha][coluna];
                   
                        inputRaster.getPixels(0,0,linha,coluna,pixels);				
                        
                        for(int w=0; w < linha; w++){
                            for(int h=0; h < coluna; h++){				
					

                                        int offset = h * linha * nbands + w * nbands;

					for(int band=0; band<nbands; band++){
						mtzImg[w][h] = pixels[offset+band];
                                                
					}
                                //System.out.println("M["+w+"]["+h+"]= "+mtzImg[w][h]);                        
				}
                                
			}
                 // System.out.println("Largura: "+linha+"\n"+"Altura: "+coluna);
                 // System.out.println("\nBandas: "+nbands+"\nRaster: "+inputRaster);
		
		}catch(Exception e){
			e.printStackTrace();
		}		
		return mtzImg;
	}      
        
        public int getAltura(String imagem){
           int altura=0; 
           try{
                BufferedImage image = ImageIO.read(new File(imagem));
                altura = image.getHeight();       
           }catch(Exception e){
                e.printStackTrace();
           }		     
           return altura;
        }
        
        public int getLargura(String imagem){
           int largura=0;
           try{
                BufferedImage image = ImageIO.read(new File(imagem));
                largura =image.getWidth();       
           }catch(Exception e){
                e.printStackTrace();
           }		     
           return largura;
        }
	
	/**
	* armazena uma imagem
	* @param mtzImg - matriz de inteiros
	* @param nomeImagem - nome da imagem a ser armazenada
	* @param extensao - extensao da imagem (e.g. JPEG) 
	*/
	public static void setPixel(int[][] mtzImg, String nomeImagem, String extensao){
		BufferedImage image = new BufferedImage(mtzImg.length,mtzImg.length,BufferedImage.TYPE_BYTE_GRAY);
		
		WritableRaster raster = image.getRaster();
		
		for(int h=0; h < mtzImg.length; h++)
			for(int w=0; w < mtzImg[h].length; w++)
				raster.setSample(w,h,0,mtzImg[h][w]);
		try{
			ImageIO.write(image, extensao, new File(nomeImagem+"."+extensao));
		}catch(IOException e){
			e.printStackTrace();
		}
	}    
}
