/**
 *Classe que conecta dois vertices, ou seja, aresta
 *@author - Wendeson da Silva olveira
 */
public class Bel{
    
    int x,y,acessor;
    Bel proximo, anterior;
    double custo; //custo de ir de um vertice a outro
    boolean done; //armazena verdadeiro se este bel ja foi visitado
    
    /**
     *Construtor
     *@param x - cordenada x da imagem
     *@param y - cordenada y da imagem
     */
    public Bel(int x, int y){
        this.x = x;
        this.y = y;
        custo = Double.MAX_VALUE;
        acessor = -1;
        proximo = anterior = null;
    }
}