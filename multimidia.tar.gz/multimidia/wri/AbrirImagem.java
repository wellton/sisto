import java.awt.*;
import javax.swing.*;
 
 
// class to display an ImageIcon on a panel
class AbrirImagem extends JPanel 
{
   private ImageIcon imageIcon; 
   private String imagemArquivo;
   // load image
   public AbrirImagem( String imagem )
   {
      imagemArquivo=imagem;
      imageIcon = new ImageIcon( imagemArquivo ); 
   } 
 
   // display imageIcon on panel
   public void paintComponent( Graphics g )
   {
      super.paintComponent( g );
      imageIcon.paintIcon( this, g, 0, 0 ); 
   } 
   public Dimension getPreferredSize()
   {
      return new Dimension( imageIcon.getIconWidth(), imageIcon.getIconHeight() );  
   } 
} 
