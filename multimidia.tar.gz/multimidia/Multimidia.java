import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.awt.Color;

class Multimidia{

	public static void main(String args []) throws Exception{

		String arquivo = "lena256";
		String extensao = "png";

		BufferedImage escalaCinza = ImageIO.read(new File (arquivo+"."+extensao));
		//primeiro: insere tamanho da imagem nova;... acho que tem um jeito mais simples de chamar apenas a imagem vazia
		BufferedImage binarizada =  ImageIO.read(new File (arquivo+"."+extensao));

		//segundo: insere tamanho da imagem para suavizar
//		BufferedImage suavizada = ImageIO.read(new File (arquivo.".".extensao));

		int largura = escalaCinza.getWidth();
		int altura = escalaCinza.getHeight();

		System.out.println(largura + "x" + altura);

		for (int x=0;x<largura;x++){
			for (int y=0;y<altura;y++){

				Color cor = new Color(escalaCinza.getRGB(x,y));
				int vermelho =(int)(cor.getRed()*0.3);
				int verde = (int)(cor.getGreen()*0.6);
				int azul = (int)(cor.getGreen()*0.1);

				int soma = vermelho + verde +azul;
				Color cinza = new Color(soma, soma, soma);
				escalaCinza.setRGB(x,y,cinza.getRGB());

				System.out.println("m["+x+"]["+y+"]: "+cor.getRed() + "," +cor.getGreen() + ","+ cor.getBlue());

				//primeiro processo: Binarização
				if(cinza.getRed()>120){
					Color bin = new Color(255, 255, 255);
					binarizada.setRGB(x, y, bin.getRGB());
				}else{
					Color bin = new Color(0, 0, 0);
					binarizada.setRGB(x, y, bin.getRGB());
				}

				//segundo processo: suavização

			}
		}
		File imagemcinza = new File(arquivo+"ImagemCinza."+extensao);
		ImageIO.write(escalaCinza,extensao,imagemcinza);

		//grava processo Binarização
		File imagembinarizada = new File(arquivo+"ImagemThresholding."+extensao);
		ImageIO.write(binarizada, extensao, imagembinarizada);

		//grava processo Suavização
//		File imagemsuavizada = new File(arquivo+"ImagemSuavizada."+extensao);
//		ImageIO.write(suavizada, extensao, imagemsuavizada);

	}
}
