<?php

echo face_count( "people.jpg",  "haarcascade.xml");
echo face_detect("people.jpg", "haarcascade.xml");

?>
