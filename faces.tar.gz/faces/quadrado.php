<?php

  $imagem = "varias.jpg";
  $base = "haarcascade.xml";

  $numeroFaces = face_count($imagem, $base);

  if($numeroFaces > 0)
  {
    $pontos = face_detect($imagem, $base);
    $imagemProcessada = processarImagem($imagem);

    $cor = imagecolorallocate($imagemProcessada, 255, 0, 0);

    foreach($pontos as $ponto)
    {
       imagesetthickness($imagemProcessada, 5);
       imagerectangle($imagemProcessada, $ponto["x"], $ponto["y"],
       $ponto["x"]+$ponto["w"], $ponto["y"]+$ponto["h"], $cor);
    }
  }
  header("Content-Type: image/jpeg");
  imagejpeg($imagemProcessada);
  imagedestroy($imagemProcessada);

  function processarImagem($imgname)
  {
    $im = imagecreatefromjpeg($imgname);

    if (!$im)
    {
      $im  = imagecreate(150, 30);
      $bgc = imagecolorallocate($im, 255, 255, 255);
      $tc  = imagecolorallocate($im, 0, 0, 0);
      imagefilledrectangle($im, 0, 0, 150, 30, $bgc);
      imagestring($im, 1, 5, 5, "Error loading $imgname", $tc);
    }
    return $im;
  }
?>
